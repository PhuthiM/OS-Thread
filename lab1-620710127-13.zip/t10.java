//5 mins
import java.util.Scanner;


public class t10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int total = 0;
        for (;;) {
            
            int number = sc.nextInt();
            if(number==0){
                break;
            }
            total += number;
        }
        System.out.println("Total : " + total);

        if (total > 0) {
            System.out.println("totol is positive number");
        } else if (total == 0) {
            System.out.println("totol is zero number");
        } else {
            System.out.println("totol is negative number");
        }
    }
}
