//2 mins
import java.util.Scanner;

public class t6 {
    public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        int number1 = sc.nextInt();
        int number2 = sc.nextInt();
        int total=number1+number2;
        System.out.println("total = " +total);
        if(total%2==0){
            System.out.println("totol is even number");
        }
        else {
                System.out.println("totol is odd number");
        }
    }
}
