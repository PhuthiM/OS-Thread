//7 mins
import java.util.Scanner;

public class t11 {

    public static void main(String[] args) {
        t11 T11 = new t11();
        System.out.println(T11.printName());
        Scanner sc = new Scanner(System.in);
        int total = 0;
        for (;;) {

            int number = sc.nextInt();
            if (number == 0) {
                break;
            }
            total += number;
        }
        System.out.println("Total : " + total);

        if (total > 0) {
            System.out.println("totol is positive number");
        } else if (total == 0) {
            System.out.println("totol is zero number");
        } else {
            System.out.println("totol is negative number");
        }
       System.out.println(T11.printName());
    }

    String printName() {
        return "620710127 Phuthita Sookhong";
    }
}
