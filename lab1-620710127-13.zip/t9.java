//5 mins
import java.util.Scanner;

public class t9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Count Num is : ");
        int Num = sc.nextInt();
        int total = 0;
        for (int i = 0; i < Num; i++) {
            int number = sc.nextInt();
            total += number;
        }
        System.out.println("Total : " + total);

        if (total > 0) {
            System.out.println("totol is positive number");
        } else if (total == 0) {
            System.out.println("totol is zero number");
        } else {
            System.out.println("totol is negative number");
        }
    }
}
