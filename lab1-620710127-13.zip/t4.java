//1 mins
import java.util.Scanner;

public class t4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int numberone = sc.nextInt();
        System.out.println("number 1 is " + numberone);
        int numbertwo = sc.nextInt();
        System.out.println("number 2 is " + numbertwo);
    }
}
