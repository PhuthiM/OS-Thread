// 30  second 
import java.util.Scanner;

public class t1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int id=sc.nextInt(); 
        System.out.println("id : "+id);
        String name=sc.next();
        System.out.println("Name : "+name);
      
    }
}
