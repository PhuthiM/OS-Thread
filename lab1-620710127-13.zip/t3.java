// 30  second 
import java.util.Scanner;

public class t3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int number = sc.nextInt();
        System.out.println("number id " + number);
    }
}
