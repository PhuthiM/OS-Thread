//1 mins
import java.util.Scanner;

public class t5 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int number1 = sc.nextInt();
        int number2 = sc.nextInt();
        System.out.println("Sum = " + (number1+number2));
    }
}
