// 30  second
import java.util.Scanner;


public class t2 {
    public static void main(String[] args) {
        System.out.println("What Color do you like ?");
        Scanner sc=new Scanner(System.in);
        String color=sc.next();
        System.out.println("I like color : "+color);
    }
}
