//3 mins
import java.util.Scanner;


public class t7 {
     public static void main(String[] args) {
         Scanner sc = new Scanner(System.in);
        int number1 = sc.nextInt();
        int number2 = sc.nextInt();
        int total=number1+number2;
        System.out.println("total = " +total);
        if(total>0){
            System.out.println("totol is positive number");
        }
        else if(total==0){
                System.out.println("totol is zero number");
        }
        else {
                System.out.println("totol is negative number");
        }
    }
}
